﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using Models;

namespace Order3.Controllers
{
    public class orderController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SelBill()
        {
            return Json(BillManager.SelBill(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult SelDetail(string id)
        {
            return Json(BillManager.SelDetail(id), JsonRequestBehavior.AllowGet);
        }

        public ActionResult SelBllno(string id)
        {
            return Json(BillManager.SelBllno(id), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Ins(tb_bill bill, List<tb_detail> detail)
        {
            return Json(BillManager.Ins(bill, detail), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Edit(tb_bill bill, List<tb_detail> detail)
        {
            return Json(BillManager.Edit(bill, detail), JsonRequestBehavior.AllowGet);
        }

    }
}
