﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    public class BillService
    {
        public static IQueryable SelBill()
        {
            OrderEntities oe = new OrderEntities();
            var str = from p in oe.tb_bill
                      orderby p.billno
                      select new
                      {
                          billno = p.billno,
                          billdate = p.billdate,
                          suppliername = p.suppliername,
                          supplieraddress = p.supplieraddress,
                          department = p.department,
                          warehouse = p.warehouse,
                          buyer = p.buyer,
                          executor = p.executor
                      };
            return str.Take(1);
        }

        public static IQueryable SelDetail(string id)
        {
            OrderEntities oe = new OrderEntities();
            var str = from p in oe.tb_detail
                      where p.billno == id
                      select new
                      {
                          billno = p.billno,
                          lineid = p.lineid,
                          goodsname = p.goodsname,
                          goodsnum = p.goodsnum,
                          goodsprice = p.goodsprice,
                          goodsmoneyamt = p.goodsmoneyamt,
                          ispresent = p.ispresent
                      };
            return str;
        }

        public static int SelBllno(string id)
        {
            OrderEntities oe = new OrderEntities();
            var str = (from p in oe.tb_bill where p.billno == id select p).Count();
            return str;
        }

        public static int Ins(tb_bill bill, List<tb_detail> detail)
        {
            OrderEntities oe = new OrderEntities();
            oe.tb_bill.Add(bill);
            foreach (var item in detail)
            {
                oe.tb_detail.Add(item);
            }
            return oe.SaveChanges();
        }

        public static int Edit(tb_bill bill, List<tb_detail> detail)
        {
            OrderEntities oe = new OrderEntities();
            var str = (from p in oe.tb_bill where p.billno == bill.billno select p).First();
            str.billdate = bill.billdate;
            str.buyer = bill.buyer;
            str.department = bill.department;
            str.executor = bill.executor;
            str.supplieraddress = bill.supplieraddress;
            str.suppliername = bill.suppliername;
            str.warehouse = bill.suppliername;

            var detailList = from p in oe.tb_detail where p.billno == bill.billno select p;
            foreach (var item in detailList)
            {
                oe.tb_detail.Remove(item);
            }
            foreach (var item in detail)
            {
                oe.tb_detail.Add(item);
            }
            return oe.SaveChanges();
        }

        
    }
}
