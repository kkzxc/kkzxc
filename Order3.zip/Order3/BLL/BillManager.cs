﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL;

namespace BLL
{
    public class BillManager
    {
        public static IQueryable SelBill()
        {
            return BillService.SelBill();
        }

        public static IQueryable SelDetail(string id)
        {
            return BillService.SelDetail(id);
        }

        public static int SelBllno(string id)
        {
            return BillService.SelBllno(id);
        }

        public static int Ins(tb_bill bill,List<tb_detail> detail)
        {
            return BillService.Ins(bill, detail);
        }

        public static int Edit(tb_bill bill, List<tb_detail> detail)
        {
            return BillService.Edit(bill, detail);
        }
    }
}
