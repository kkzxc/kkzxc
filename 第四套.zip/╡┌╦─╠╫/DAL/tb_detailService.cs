﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
namespace DAL
{
    public class tb_detailService
    {
        #region 赋值
        public static IQueryable fz(string id)
        {
            OrderEntity us = new OrderEntity();
            var obj = from p in us.tb_detail
                      where p.billno == id
                      select new
                      {
                          billno = p.billno,
                          lineid = p.lineid,
                          goodsname = p.goodsname,
                          goodsnum = p.goodsnum,
                          goodsprice = p.goodsprice,
                          goodsmoneyamt = p.goodsmoneyamt,
                          ispresent = p.ispresent
                      };
            return obj;
        }
        #endregion
    }
}
