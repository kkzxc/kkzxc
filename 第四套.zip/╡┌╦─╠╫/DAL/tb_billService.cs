﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    public class tb_billService
    {
        #region 分页
        public static PageList fy(int PageIndex, int PageSize)
        {
            OrderEntity us = new OrderEntity();
            var obj = from p in us.tb_bill
                      orderby p.billno
                      select new
                      {
                          billno = p.billno,
                          billdate = p.billdate,
                          suppliername = p.suppliername,
                          supplieraddress = p.supplieraddress,
                          department = p.department,
                          warehouse = p.warehouse,
                          buyer = p.buyer,
                          executor = p.executor
                      };
            PageList list = new PageList();
            int count = obj.Count();
            list.PageCount = count % PageSize == 0 ? count / PageSize : count / PageSize + 1;
            list.DateList = obj.Skip((PageIndex - 1) * PageSize).Take(PageSize);
            return list;
        }
        #endregion
        #region 新增
        public static int xz(tb_bill info, List<tb_detail> list)
        {
            OrderEntity us = new OrderEntity();
            us.tb_bill.Add(info);
            foreach (var item in list)
            {
                us.tb_detail.Add(item);
            }
            return us.SaveChanges();
        }
        #endregion
        #region 判断
        public static int pd(string id)
        {
            OrderEntity us = new OrderEntity();
            var obj = (from p in us.tb_bill where p.billno == id select p).Count();
            return obj;
        }
        #endregion
        #region 修改
        public static int xg(tb_bill info, List<tb_detail> list)
        {
            OrderEntity us = new OrderEntity();
            var obj = (from p in us.tb_bill where p.billno == info.billno select p).First();
            obj.billno = info.billno;
            obj.billdate = info.billdate;
            obj.suppliername = info.suppliername;
            obj.supplieraddress = info.supplieraddress;
            obj.department = info.department;
            obj.warehouse = info.warehouse;
            obj.buyer = info.buyer;
            obj.executor = info.executor;
            var sc = from p in us.tb_detail where p.billno == info.billno select p;
            foreach (var item in sc)
            {
                us.tb_detail.Remove(item);
            }
            foreach (var item in list)
            {
                us.tb_detail.Add(item);
            }
            return us.SaveChanges();
        }
        #endregion
        #region 时间
        public static string sj(DateTime date)
        {
            OrderEntity us = new OrderEntity();
            string qe = date.ToString("yyyyMMdd");
            var obj = from p in us.tb_bill where p.billno.Contains(qe) select p.billno;
            if (obj.Count() > 0)
            {
                long qwe = long.Parse(obj.Max());
                return (qwe + 1).ToString();
            }
            else
            {
                return qe + "001";
            }
        }
        #endregion

        public static PageList QuerryAll(int pageindex, int pagesize)
        {
            OrderEntity entity = new OrderEntity();
            var obj = from p in entity.tb_bill
                      orderby p.billno
                      select new
                      {
                          billno = p.billno,
                          billdate = p.billdate,
                          suppliername = p.suppliername,
                          supplieraddress = p.supplieraddress,
                          department = p.department,
                          warehouse = p.warehouse,
                          buyer = p.buyer,
                          executor = p.executor
                      };
            PageList list = new PageList();
            var count = obj.Count();
            list.PageCount = count % pagesize == 0 ? count / pagesize : count / pagesize + 1;
            list.DateList = obj.Skip((pageindex - 1) * pagesize).Take(pagesize);
            return list;
        }
        public static int xinzeng(tb_bill bill, List<tb_detail> list)
        {
            OrderEntity entity = new OrderEntity();
            entity.tb_bill.Add(bill);
            foreach (var item in list)
            {
                entity.tb_detail.Add(item);
            }
            return entity.SaveChanges();
        }

        public static int Delete(string id)
        {
            OrderEntity entity = new OrderEntity();
            var obj = (from p in entity.tb_detail where p.billno == id select p).First();
            var key = from p in entity.tb_bill where p.billno == id select p;
            entity.tb_detail.Remove(obj);
            foreach (var item in key)
            {
                entity.tb_bill.Remove(item);
            }
            return entity.SaveChanges();
        }

        //public static int Xiugai(tb_bill bill, List<tb_detail> list)
        //{
        //    OrderEntity entity = new OrderEntity();
        //    var obj = (from p in entity.tb_bill where p.billno == bill.billno select p).First();
        //    obj.billno = bill.billno;
        //    obj.billdate = bill.billdate;
        //    obj.suppliername = bill.suppliername;
        //    obj.supplieraddress = bill.supplieraddress;
        //    obj.department = bill.department;
        //    obj.warehouse = bill.warehouse;
        //    obj.buyer = bill.buyer;
        //    obj.executor = bill.executor;
        //    var key = from p in entity.tb_detail where p.billno == bill.billno select p;

        //}
    }
}
