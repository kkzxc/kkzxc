﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using BLL;
namespace 第四套.Controllers
{
    public class infooController : Controller
    {
        //
        // GET: /infoo/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult cxym()
        {
            return View();
        }
        public ActionResult fy(int PageIndex, int PageSize)
        {
            return Json(tb_billManager.fy(PageIndex, PageSize), JsonRequestBehavior.AllowGet);
        }
        public ActionResult fz(string id)
        {
            return Json(tb_detailManager.fz(id), JsonRequestBehavior.AllowGet);
        }
        public ActionResult xz(tb_bill info, List<tb_detail> list)
        {
            return Json(tb_billManager.xz(info, list), JsonRequestBehavior.AllowGet);
        }
        public ActionResult pd(string id)
        {
            return Json(tb_billManager.pd(id), JsonRequestBehavior.AllowGet);
        }
        public ActionResult xg(tb_bill info, List<tb_detail> list)
        {
            return Json(tb_billManager.xg(info, list), JsonRequestBehavior.AllowGet);
        }
    }
}
