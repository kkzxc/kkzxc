﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL;

namespace BLL
{
    public class tb_detailManager
    {
        public static IQueryable fz(string id)
        {
            return tb_detailService.fz(id);
        }
    }
}
