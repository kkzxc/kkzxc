﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL;

namespace BLL
{
    public class tb_billManager
    {
        public static PageList fy(int PageIndex, int PageSize)
        {
            return tb_billService.fy(PageIndex, PageSize);
        }
        public static int xz(tb_bill info, List<tb_detail> list)
        {
            return tb_billService.xz(info, list);
        }
        public static int pd(string id)
        {
            return tb_billService.pd(id);
        }
        public static int xg(tb_bill info, List<tb_detail> list)
        {
            return tb_billService.xg(info, list);
        }
    }
}
