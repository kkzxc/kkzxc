﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class PageList
    {
        public int pageCount { get; set; }   //总条数

        public IQueryable pageData { get; set; }    //数据
    }
}
