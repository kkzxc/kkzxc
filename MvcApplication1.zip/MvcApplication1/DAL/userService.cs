﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    //用户表
    public class userService
    {
        public static int uLogin(string userName, string userPwd)
        {
            xiaowuEntities xiao = new xiaowuEntities();
            var str = (from p in xiao.user where p.userName == userName && p.userPwd == userPwd select p).Count();
            return str;
        }
    }
}
