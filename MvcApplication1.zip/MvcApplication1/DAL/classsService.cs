﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    //教室表
   public class classsService
    {
       public static IQueryable SelectClassroom()
       {
           xiaowuEntities entity = new xiaowuEntities();
           var obj = from p in entity.classs
                     orderby p.classsID
                     select new
                     {
                         classsID=p.classsID,
                         classsName=p.classsName,
                         rongNaNum=p.rongNaNum,
                         xZhou=p.xZhou,
                         yZhou=p.yZhou
                     };
           return obj.Take(1);
       }

       public static int AddClassroom(classs cl)
       {
           xiaowuEntities entity = new xiaowuEntities();
          entity.classs.Add(cl);
          return entity.SaveChanges();
       }

       public static int DelClassroom(int no)
       {
           xiaowuEntities entity = new xiaowuEntities();
           var obj = (from p in entity.classs where p.classsID == no select p).First();
           entity.classs.Remove(obj);

           return entity.SaveChanges();
       }

       public static int EditClassroom(classs cl)
       {
           xiaowuEntities entity = new xiaowuEntities();
           var obj = (from p in entity.classs where p.classsID == cl.classsID select p).First();
           obj.classsID = cl.classsID;
           obj.classsName = cl.classsName;
           obj.rongNaNum = cl.rongNaNum;
           obj.xZhou = cl.xZhou;
           obj.yZhou = cl.yZhou;
           return entity.SaveChanges();
       }

       public static int CheckIsTrue(int no)
       {
           xiaowuEntities entity = new xiaowuEntities();
           var obj = (from p in entity.classs
                      where p.classsID == no
                      select p).Count();
           return obj;
       }

       public static IQueryable VariousSeach(string key)
       {
           xiaowuEntities entity = new xiaowuEntities();
           var obj = from p in entity.classs
                      where p.classsName==key
                     orderby p.classsID
                     select new
                     {
                         classsID = p.classsID,
                         classsName = p.classsName,
                         rongNaNum = p.rongNaNum,
                         xZhou = p.xZhou,
                         yZhou = p.yZhou
                     };
           return obj.Take(1);
       }
    }
}
