﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    //缴费类型表
    public class jiaoFeiTypeService
    {
    }
}
