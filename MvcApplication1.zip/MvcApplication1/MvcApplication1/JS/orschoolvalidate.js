﻿$(document).ready(function () {
    $(".orshop-kendowindowcontent").find("[datavalid]").bind("change", function () { 
        var role = $(this).attr("datavalid");
        switch (role) {
            case "numbertwozerotimehour":
                ValidateNumberTwoZeroTimeHour(this)
                break;
            case "numbertwozerotimeminute":
                ValidateNumberTwoZeroTimeMinute(this)
                break;
            case "date":
                IsDate(this);
                break;
            case "datemonthday":
                IsDateMonthDay(this);
                break;
        }
    });
    $(".panel-body").find("[datavalid]").bind("change", function () {
        var role = $(this).attr("datavalid");
        switch (role) {
            case "numbertwozerotimehour":
                ValidateNumberTwoZeroTimeHour(this)
                break;
            case "numbertwozerotimeminute":
                ValidateNumberTwoZeroTimeMinute(this)
                break;
            case "date":
                IsDate(this);
                break;
            case "datemonthday":
                IsDateMonthDay(this);
                break;
        }
    });
});
//验证时间数字正整数小时
function ValidateNumberTwoZeroTimeHour(obj) {
    var value = $(obj).val();
    if (value == null || value=="") {
        $(obj).val("00");
    }
    value = value.replace(/^\s+|\s+$/g, "");
    $(obj).val(value);
    var name = GetValue(value);
    var Regx = /^[0-9]*$/;
    if (Regx.test(value)) {
       
    } else {
        $(obj).val("00");
    }
    if (value < 0 || value > 24)
    {
        CheckInputShowSelfNoId("时间范围为0到24小时制");
        $(obj).val("00");
    }
    if (value == 0) {
        $(obj).val("00");
    }
};
//验证时间数字正整数分
function ValidateNumberTwoZeroTimeMinute(obj) {
    var value = $(obj).val();
    if (value == null || value == "") {
        $(obj).val("00");
    }
    value = value.replace(/^\s+|\s+$/g, "");
    $(obj).val(value);
    var name = GetValue(value);
    var Regx = /^[0-9]*$/;
    if (Regx.test(value)) {

    } else {
        $(obj).val("00");
    }
    if (value < 0 || value > 60) {
        CheckInputShowSelfNoId("分钟范围为0到60分钟");
        $(obj).val("00");
    }
    if (value == 0) {
        $(obj).val("00");
    }
};
function GetValue(value) {
    value = value.replace(/\ +/g, ""); //去空格
    value = value.replace(/[\r\n]/g, ""); //去掉回车换行
    value = value.replace(/：/g, ''); //去掉冒号
    value = value.replace(/\*/g, ""); //去掉*
    return value;
}
//判断日期是否合法 
function IsDate(obj) {
    var value = $(obj).val();
    var regex = new RegExp("^(?:(?:([0-9]{4}(-|\/)(?:(?:0?[1,3-9]|1[0-2])(-|\/)(?:29|30)|((?:0?[13578]|1[02])(-|\/)31)))|([0-9]{4}(-|\/)(?:0?[1-9]|1[0-2])(-|\/)(?:0?[1-9]|1\\d|2[0-8]))|(((?:(\\d\\d(?:0[48]|[2468][048]|[13579][26]))|(?:0[48]00|[2468][048]00|[13579][26]00))(-|\/)0?2(-|\/)29))))$");
    var dateValue = value;
    if (!regex.test(dateValue)) {
        CheckInputShowSelfNoId("日期有误！");
        $(obj).val(new Date().Format("yyyy-MM-dd"));
        this.focus();
        return;
    }
}
//判断日期是否合法 
function IsDateMonthDay(obj) {
    var value = "2005-"+$(obj).val();
    var regex = new RegExp("^(?:(?:([0-9]{4}(-|\/)(?:(?:0?[1,3-9]|1[0-2])(-|\/)(?:29|30)|((?:0?[13578]|1[02])(-|\/)31)))|([0-9]{4}(-|\/)(?:0?[1-9]|1[0-2])(-|\/)(?:0?[1-9]|1\\d|2[0-8]))|(((?:(\\d\\d(?:0[48]|[2468][048]|[13579][26]))|(?:0[48]00|[2468][048]00|[13579][26]00))(-|\/)0?2(-|\/)29))))$");
    var dateValue = value;
    if (!regex.test(dateValue)) {
        CheckInputShowSelfNoId("日期有误！");
        $(obj).val(new Date().Format("MM-dd"));
        this.focus();
        return;
    }
}
//下面两个都 不能小于零，如果小于零会置于零
function ValidateMoney(obj) {
    var amount = $(obj).val();
    var amountTest = /^\d+\.?\d{0,2}$/;
    if (amountTest.test(amount) == false) {
        if (isNaN(amount))
        { $(obj).val("0.00"); }
        else
        {    
            if (fmoney(amount) > 0)
            { $(obj).val(fmoney(amount)); }
            else
            { $(obj).val("0.00"); }
        }      
        return;
    }
}
function ValidateMoneyInput(obj) {
    var amount = $(obj).val();
    if (amount != "")
    {
        var amountTest = /^\d+\.?\d{0,2}$/;
        if (amountTest.test(amount) == false) {
            if (isNaN(amount))
            { $(obj).val("0.00"); }
            else
            {
                if (fmoney(amount) > 0)
                { $(obj).val(fmoney(amount)); }
                else
                { $(obj).val("0.00"); }
            }
            return;
        }
    }
}
function ValidateMoneyonBlur(obj) {
    var amount = $(obj).val();
    var amountTest = /^\d+\.?\d{0,2}$/;
    if (amountTest.test(amount) == false) {
        if (isNaN(amount))
        { $(obj).val("0.00"); }
        else
        {
            if (fmoney(amount) > 0)
            { $(obj).val(fmoney(amount)); }
            else
            { $(obj).val("0.00"); }
            
        }
        return;
    }
    if (fmoney(amount) > 0)
    { $(obj).val(fmoney(amount)); }
    else
    { $(obj).val("0.00"); }
}
function ValidateNum(obj) {
    var amount = $(obj).val();
    var amountTest = /^[0-9]*[1-9][0-9]*$/;
    if (amountTest.test(amount) == false) {
        if (isNaN(amount))
        { $(obj).val("0"); }
        else
        {
            $(obj).val(fmoney(amount,0));
        }
        return;
    }
    $(obj).val(fmoney(amount, 0));
}
function ValidateNumInput(obj) {
    var amount = $(obj).val();
    if (amount != "")
    {
        var amountTest = /^[0-9]*[1-9][0-9]*$/;
        if (amountTest.test(amount) == false) {
            if (isNaN(amount))
            { $(obj).val("0"); }
            else
            {
                $(obj).val(fmoney(amount, 0));
            }
            return;
        }
        $(obj).val(fmoney(amount, 0));
    }
}
function ValidatePositiveInteger(obj) {
    var amount = $(obj).val();
    var amountTest = /^[0-9]*[1-9][0-9]*$/;
    if (amountTest.test(amount) == false) {
        if (isNaN(amount))
        { $(obj).val("0"); }
        else
        {
            $(obj).val(Number(amount));
        }
        return;
    }
    $(obj).val(Number(amount));
}
function ValidatePositiveIntegerInput(obj) {
    var amount = $(obj).val();
    if (amount != "")
    {
        var amountTest = /^[0-9]*[1-9][0-9]*$/;
        if (amountTest.test(amount) == false) {
            if (isNaN(amount))
            { $(obj).val("0"); }
            else
            {
                $(obj).val(Number(amount));
            }
            return;
        }
        $(obj).val(Number(amount));
    }
}
//格式化空值转化为0
function femptyzero(s)
{
    var n = 0;
    if (s == "" || s == undefined || s==null) {
        n = 0;
    }
    else { n = fmoney(s) }
    return n;
}
//格式化bool true false
function femptybool(s,num) {
    var n = true;
    if (s == "" || s == undefined || s == null) {
        n = num==1?true:false;
    } else { n = s }
    return n;
}

//格式化金额
function fmoney(s, n) {
    if (!s)
    {
        s = 0;
    }
    if (s == "") {
        s = 0;
    }
    n = n > 0 && n <= 20 ? n : 2;
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";//更改这里n数也可确定要保留的小数位
    var l = s.split(".")[0].split("").reverse(),
    r = s.split(".")[1];
    t = "";
    for (i = 0; i < l.length; i++) {
        // t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "" : "");
    }

    return parseFloat(Math.formatFloatMoeny(parseFloat(t.split("").reverse().join("") + "." + r.substring(0, 2)), 6).toFixed(2));//保留2位小数  如果要改动 把substring 最后一位数改动就可 
}
Math.formatFloatMoeny = function (f, digit) {
    var m = Math.pow(10, digit);
    return parseInt(f * m, 10) / m;
}
function toDecimal2(x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return false;
    }
    var f = Math.round(x * 100) / 100;
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
        rs = s.length;
        s += '.';
    }
    while (s.length <= rs + 2) {
        s += '0';
    }
    return s;
}
function ShieldNoNum() {//屏蔽非数字和非退格符
    var k = event.keyCode;   //48-57是大键盘的数字键，96-105是小键盘的数字键，8是退格符←
    if ((k <= 57 && k >= 48) || (k <= 105 && k >= 96) || (k == 8) || k == 110 || k == 190) {
        return true;
    } else {
        return false;
    }
}
function ShieldNoNumDian() {//屏蔽非数字和非退格符
    var k = event.keyCode;   //48-57是大键盘的数字键，96-105是小键盘的数字键，8是退格符←
    if ((k <= 57 && k >= 48) || (k <= 105 && k >= 96) || (k == 8)) {
        return true;
    } else {
        return false;
    }
}
// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： 
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
Date.prototype.Format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
