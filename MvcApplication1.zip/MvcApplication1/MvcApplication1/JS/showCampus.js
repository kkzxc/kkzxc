﻿window.parent.$(".topcampus").show();
window.parent.$("#topcampusSure .sure").show();
window.parent.$(".dropdown-menu ul li:first").show();
window.parent.$(".dropdown-menu ul li input").show();
window.parent.$('.dropdown-menu ul li span').unbind("click");