
$(function () {
    //使用title内容作为tooltip提示文字
    $(document).tooltip({
        track: true
    });
    $(".nav-tabs:eq(0)").show();
    $('body').css('background-color', '#09C');


    // 侧边导航二级菜单切换（展开式）
    $('.nav-tabs').each(function () {
        $(this).find('dl > dt > a').each(function (i) {
            $(this).parent().next().css('top', (-70) * i + 'px');
            $(this).click(function () {
                if ($('.orshopadmin-container').hasClass('fold')) {
                    return;
                }
                $('.sub-menu').hide();
                $('.nav-tabs').find('dl').removeClass('active');
                $(this).parents('dl:first').addClass('active');
                $(this).parent().next().show().find('a:first').click();
            });
        });
    });

    // 侧边导航展示形式切换
    $('#foldSidebar > i').click(function () {
        if ($('.orshopadmin-container').hasClass('unfold')) {
            $(this).addClass('fa-indent').removeClass('fa-outdent');
            $('.sub-menu').removeAttr('style');
            $('.orshopadmin-container').addClass('fold').removeClass('unfold');
        } else {
            $(this).addClass('fa-outdent').removeClass('fa-indent');
            $('.nav-tabs').each(function (i) {
                $(this).find('dl').each(function (i) {
                    $(this).find('dd').css('top', (-70) * i + 'px');
                    if ($(this).hasClass('active')) {
                        $(this).find('dd').show();
                    }
                });
            });
            $('.orshopadmin-container').addClass('unfold').removeClass('fold');
        }
    });

    // 侧边导航三级级菜单点击
    $('.sub-menu').find('a').click(function () {
        openItem($(this).attr('data-param'));
    });

    // 顶部各个模块切换
    $('.orshop-module-menu').find('a').click(function () {
        if ($('.orshopadmin-container').hasClass('unfold')) {
            $('.sub-menu').hide();
        }
        $('.orshop-module-menu').find('li').removeClass('active');
        _modules = $(this).parent().addClass('active').attr('data-param');
        $('div[id^="orshopadminNavTabs_"]').hide();
        if (_modules.indexOf('platform') > -1) {
            $('#orshopadminNavTabs_' + _modules).show().find('dl').removeClass('active').last().addClass('active').find('dd').find('li > a:first').click();
        }
        else {
            $('#orshopadminNavTabs_' + _modules).show().find('dl').removeClass('active').first().addClass('active').find('dd').find('li > a:first').click();
        }
    });


    // 导航菜单  显示
    $('a[nctype="map_on"],a[class="add-menu"]').click(function () {
        $('div[nctype="map_nav"]').show();
    });
    // 导航菜单 隐藏
    $('a[nctype="map_off"]').click(function () {
        $('div[nctype="map_nav"]').hide();
    });
    // 三级导航菜单切换
    $('li[class="treeviewdown"]').children("span").click(function () {
        var $this = $(this);
        //$this.addClass('active')
        $this.parent().toggleClass("clickactive");
        $this.find('i').toggleClass("fa-angle-down");
        $this.parent().children('ul').toggle();
    });
    // 导航菜单切换
    $('a[data-param^="map-"]').click(function () {
        $(this).parent().addClass('selected').siblings().removeClass('selected');
        $('div[data-param^="map-"]').hide();
        $('div[data-param="' + $(this).attr('data-param') + '"]').show();
    });
    $('div[data-param^="map-"]').find('i').click(function () {
        var $this = $(this);
        var _value = $this.prev().attr('data-param');
    }).end().find('a').click(function () {
        openItem($(this).attr('data-param'));
    });
    // 导航菜单默认值显示第一组菜单
    $('div[data-param^="map-"]:first').nextAll().hide();
    $('A[data-param^="map-"]:first').parent().addClass('selected');

    // 待办事项
    var _commonPendingMatters = 0;
    if ($.cookie('commonPendingMatters') == null) {
        $.ajax({
            url: '#',
            async: false,
            success: function (data) {
                _commonPendingMatters = parseInt(data);
                $.cookie('commonPendingMatters', _commonPendingMatters, { expires: 1 / 24 });   // 一小时更新一次
            }
        });
    } else {
        _commonPendingMatters = parseInt($.cookie('commonPendingMatters'));;
    }
    if (_commonPendingMatters > 0) {
        $('li[nctype="pending_matters"]').show().find('em').html($.cookie('commonPendingMatters'));
    }
});

// 点击菜单，iframe页面跳转
function openItem(param) {
    if ($('#CampusCount').val() == "0" && param.indexOf("CampusList") < 1) {
        var dialogNoCampus = $("#dialogNoCampus");
        dialogNoCampus.kendoDialog({
            closable: false,
            width: "400px",
            title: "提示",
            visible: false,
            actions: [
            {
                text: '确认',
                primary: true,
                action: onSureNoCampus
            }
            ]
        }).data("kendoDialog");
        dialogNoCampus.data("kendoDialog").open(); return false;
    }

    $('.sub-menu,.orshop-module-menu').find('li').removeClass('active');
    data_str = param.split('|');
    $this = $('div[id^="orshopadminNavTabs_"]').find('a[data-param="' + param + '"]');
    if ($('.orshopadmin-container').hasClass('unfold')) {
        $('.sub-menu').hide();
        $this.parents('dd:first').show();
    }
    $('div[id^="orshopadminNavTabs_"]').hide().find('dl').removeClass('active');
    $('li[data-param="' + data_str[2] + '"]').addClass('active');
    $this.parent().addClass('active').parents('dl:first').addClass('active').parents('div:first').show();
    if (data_str[1] == "")
    { $('#workspace').attr('src', '/' + data_str[0]); }
    else
    { $('#workspace').attr('src', '/' + data_str[0] + '/' + data_str[1] + '/'); }

    $.cookie('workspaceParam', data_str[0] + '|' + data_str[1] + '|' + data_str[2], { expires: 1, path: "/" });
}