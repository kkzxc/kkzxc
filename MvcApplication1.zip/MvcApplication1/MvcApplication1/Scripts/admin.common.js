window.parent.$(".throbber").hide();
function setLocation(url) {
    window.location.href = url;
}
function LoadShow()
{
    $("#loading").show();
}
function LoadHide() {
    $("#loading").hide();
}
//输入框检测
function CheckInputShowSelf(title, id, isborder) {
    $("#toastjs").html(title + "!");
    $('#' + id + '').css('border', '1px solid red');
    if (isborder == 1)
    { setTimeout(function () { $('#' + id + '').css('border', 'none'); }, 3000); }
    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowChildren(title, id, isborder) {
    $("#toastjs").html(title + "!");
    $("#window iframe").contents().find('#' + id + '').css('borderColor', 'red');
    if (isborder == 1)
    { setTimeout(function () { $("#window iframe").contents().find('#' + id + '').css('border', 'none'); }, 3000); }
    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowSelfNoId(title) {
    $("#toastjs").html(title);
    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowSelfNoIdTime(title,time) {
    $("#toastjs").html(title);
    $("#toastjs").show();
    $("#toastjs").delay(time).fadeOut("fast");
}
function CheckInputShowSelfNoIdParent(title) {
    window.parent.$("#toastjs").html(title + "!");
    window.parent.$("#toastjs").show();
    window.parent.$("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowSelfNoIdParentWindow(title) {
    window.parent.$("#window iframe").contents().find("#toastjs").html(title + "!");
    window.parent.$("#window iframe").contents().find("#toastjs").show();
    window.parent.$("#window iframe").contents().find("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShow(title, id,isborder)
{
    $("#toastjs").html(title + "不能为空!");
    $('#' + id + '').css('border', '1px solid red');
    if (isborder == 1)
    { setTimeout(function () { $('#' + id + '').css('border', 'none'); }, 3000); }
    
    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowHideColor(title, id, isborder) {
    $("#toastjs").html(title + "不能为空!");
    $('#' + id + '').css('border', '1px solid red');
    if (isborder == 1)
    { setTimeout(function () { $('#' + id + '').css('border-color', '#ddd'); }, 3000); }

    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowTitleHideColor(title, id, isborder) {
    $("#toastjs").html(title);
    $('#' + id + '').css('border', '1px solid red');
    if (isborder == 1)
    { setTimeout(function () { $('#' + id + '').css('border-color', '#ddd'); }, 3000); }

    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputShowDiv(title, id) {
    $("#toastjs").html(title + "不能为空!");
    $('#' + id + '').css('border', '1px solid red');
    //setTimeout(function () { $('#' + id + '').css('border', ''); }, 3000);
    $("#toastjs").show();
    $("#toastjs").delay(3000).fadeOut("fast");
}
function CheckInputClear()
{
    $("div").find("input").css('borderColor', '');
    $("div").find("div").css('border', '');
}
function CheckInputClearChildren() {
    $("#window iframe").contents().find("div").find("input").css('borderColor', '');
    $("#window iframe").contents().find("div").find("div").css('border', '');
}
function KendoGridReplaceString(value) {
    return value.replace("'", "’").replace("\"", "”");
}
//----------------------------------------------------
function bindBootstrapTabSelectEvent(tabsId) {
    $('#' + tabsId + ' > ul li a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        var tabName = $(e.target).attr("data-tab-name");
        $("#selected-tab-name").val(tabName);
    });
}
function OpenWindowkendoNoframe(title, url, wwidth, wheight) {
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = document.body.clientHeight - 70;
    if (parseInt(wheight) > iframeheight) { wheight = iframeheight }
    var myWindow = $("#window");
    if (myWindow.data("kendoWindow"))
    { myWindow.data("kendoWindow").destroy(); }

    if (!myWindow.data("kendoWindow")) {
        myWindow.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {
            },
            open: function (e) {
            },
            modal: true,
            scrollable: false
        });
    }
    $("#close").click(function (e) {
        myWindow.data("kendoWindow").close();
    });
    myWindow.data("kendoWindow").center().open();
}

function OpenWindowkendo(title, url,wwidth,wheight)
{
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = document.body.clientHeight - 55;
    if (parseInt(wheight) > iframeheight) {
        wheight = iframeheight;
    }
    var myWindow = $("#window");
    if (myWindow.data("kendoWindow"))
    { myWindow.data("kendoWindow").destroy();  }
    
    if (!myWindow.data("kendoWindow")) {
        myWindow.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {
            },
            resize: function () {
                ResizeDialog();
            },
            open: function (e) {
            },
            modal: true,          
            iframe: true,
            scrollable: false
        });
    }
    $("#close").click(function (e) {
        myWindow.data("kendoWindow").close();
        
    });
    myWindow.data("kendoWindow").center().open();
    $("#window iframe").load(function () {
        ResizeDialog();
    });
}
function OpenWindowkendoTwo(title, url, wwidth, wheight) {
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = window.parent.document.body.clientHeight - 55;
    if (parseInt(wheight) > iframeheight) {
        wheight = iframeheight;
    }
    var myWindowtwo = window.parent.$("#windowtwo");

    if (myWindowtwo.data("kendoWindow"))
    { myWindowtwo.data("kendoWindow").destroy(); }

    if (!myWindowtwo.data("kendoWindow")) {
        myWindowtwo.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {
            },
            resize: function () {
                ResizeDialogTwo();
            },
            open: function (e) {
            },
            modal: true,
            iframe: true,
            scrollable: false
        });
    }
    window.parent.$("#closetwo").click(function (e) {
        myWindowtwo.data("kendoWindow").close();

    });
    myWindowtwo.data("kendoWindow").center().open();
    window.parent.$("#windowtwo iframe").load(function () {
        ResizeDialogTwo();
    });
}

function OpenWindowkendoMax(title, url, wwidth, wheight) {
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = document.body.clientHeight - 55;
    if (parseInt(wheight) > iframeheight) {
        wheight = iframeheight;
    }
    var myWindow = $("#window");

    if (myWindow.data("kendoWindow"))
    { myWindow.data("kendoWindow").destroy(); }

    if (!myWindow.data("kendoWindow")) {
        myWindow.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {               
                var parantMax = window.parent.$("#window").data("kendoWindow");
                if (typeof (parantMax) != "undefined")
                { parantMax.maximize(); parantMax.toggleMaximization(); }
            },
            resize: function () {
                ResizeDialog();
            },
            open: function (e) {
            },
            modal: true,
            iframe: true,
            scrollable: false
        });
    }
    $("#close").click(function (e) {
        myWindow.data("kendoWindow").close();
    });
    var parantMax = window.parent.$("#window").data("kendoWindow");
    if (typeof (parantMax) != "undefined")
    { parantMax.toggleMaximization(); }
    myWindow.data("kendoWindow").center().open();
    $("#window iframe").load(function () {
        ResizeDialog();
    });
}

function OpenWindowkendoParameter(title, url, wwidth, wheight,parameter,paravalue) {
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = document.body.clientHeight - 55;
    if (parseInt(wheight) > iframeheight) {
        wheight = iframeheight;
    }
    var myWindow = $("#window");

    if (myWindow.data("kendoWindow"))
    { myWindow.data("kendoWindow").destroy(); }

    if (!myWindow.data("kendoWindow")) {
        myWindow.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {
            },
            resize: function () {
                ResizeDialog();
            },
            open: function (e) {
            },
            modal: true,
            iframe: true,
            scrollable: false
        });
    }
    $("#close").click(function (e) {
        myWindow.data("kendoWindow").close();

    });
    myWindow.data("kendoWindow").center().open();
    $("#window iframe").load(function () {
        ResizeDialogParameter(parameter, paravalue);
    });
}

function OpenWindowkendoParameterMax(title, url, wwidth, wheight, parameter, paravalue) {
    if (!wwidth) { wwidth = "720px"; }
    if (!wheight) { wheight = "505px"; }
    var iframeheight = document.body.clientHeight - 55;
    if (parseInt(wheight) > iframeheight) {
        wheight = iframeheight;
    }
    var myWindow = $("#window");

    if (myWindow.data("kendoWindow"))
    { myWindow.data("kendoWindow").destroy(); }

    if (!myWindow.data("kendoWindow")) {
        myWindow.kendoWindow({
            width: wwidth,
            height: wheight,
            title: title,
            actions: [
        "Pin",
        "Minimize",
        "Maximize",
        "Close"
            ],
            content: url,
            resizable: true,
            close: function (e) {
                var parantMax = window.parent.$("#window").data("kendoWindow");
                if (typeof (parantMax) != "undefined")
                { parantMax.maximize(); parantMax.toggleMaximization(); }
            },
            resize: function () {
                ResizeDialog();
            },
            open: function (e) {
            },
            modal: true,
            iframe: true,
            scrollable: false
        });
    }
    $("#close").click(function (e) {
        myWindow.data("kendoWindow").close();

    });
    var parantMax = window.parent.$("#window").data("kendoWindow");
    if (typeof (parantMax) != "undefined")
    { parantMax.toggleMaximization(); }
    myWindow.data("kendoWindow").center().open();
    $("#window iframe").load(function () {
        ResizeDialogParameter(parameter, paravalue);
    });
}

function ResizeDialog() {
    var h = $("#window iframe").contents().find('body').height();
    //var headH = 80;
    var headH = $("#window iframe").contents().find('.orshop-kendowindowbottom').outerHeight(true);
    var contH = h - headH;
    $("#window iframe").contents().find('.orshop-kendowindowcontent').height(contH).css("overflow", "auto");
}
function ResizeDialogTwo() {
    var h = window.parent.$("#windowtwo iframe").contents().find('body').height();
    //var headH = 80;
    var headH = window.parent.$("#windowtwo iframe").contents().find('.orshop-kendowindowbottom').outerHeight(true);
    var contH = h - headH;
    window.parent.$("#windowtwo iframe").contents().find('.orshop-kendowindowcontent').height(contH).css("overflow", "auto");
}
function ResizeDialogParameter(parameter, paravalue) {
    var h = $("#window iframe").contents().find('body').height();
    //var headH = 80;
    var headH = $("#window iframe").contents().find('.orshop-kendowindowbottom').outerHeight(true);
    var contH = h - headH;
    $("#window iframe").contents().find('.orshop-kendowindowcontent').height(contH).css("overflow", "auto");
    var parameterarr = parameter.split('|');
    if (typeof (paravalue) != "object")
    { var paravaluearr = paravalue.split('|'); }
    else
    { paravaluearr = paravalue; }
    $.each(parameterarr, function (i, val) {
        $("#window iframe").contents().find('#' + parameterarr[i] + '').val(paravaluearr[i]);
    });
}

function OpenWindow(query, w, h, scroll) {
    var l = (screen.width - w) / 2;
    var t = (screen.height - h) / 2;

    winprops = 'resizable=1, height=' + h + ',width=' + w + ',top=' + t + ',left=' + l + 'w';
    if (scroll) winprops += ',scrollbars=1';
    var f = window.open(query, "_blank", winprops);
}

function showThrobber(message) {
    window.parent.$('.throbber-header').html(message);
    window.setTimeout(function () {
        window.parent.$(".throbber").show();
    }, 1000);
}

$(document).ready(function () {
    $("#CampusAll").val(window.parent.$("#CampusAllTop").val());
    $('.multi-store-override-option').each(function (k, v) {
        checkOverriddenStoreValue(v, $(v).attr('data-for-input-selector'));
    });
});

function checkAllOverriddenStoreValue(item) {
    $('.multi-store-override-option').each(function (k, v) {
        $(v).attr('checked', item.checked);
        checkOverriddenStoreValue(v, $(v).attr('data-for-input-selector'));
    });
}

function checkOverriddenStoreValue(obj, selector) {
    var elementsArray = selector.split(",");
    if (!$(obj).is(':checked')) {
        $(selector).attr('disabled', true);
        //Kendo UI elements are enabled/disabled some other way
        $.each(elementsArray, function(key, value) {
            var kenoduiElement = $(value).data("kendoNumericTextBox");
            if (kenoduiElement !== undefined && kenoduiElement !== null) {
                kenoduiElement.enable(false);
            }
        }); 
    }
    else {
        $(selector).removeAttr('disabled');
        //Kendo UI elements are enabled/disabled some other way
        $.each(elementsArray, function(key, value) {
            var kenoduiElement = $(value).data("kendoNumericTextBox");
            if (kenoduiElement !== undefined && kenoduiElement !== null) {
                kenoduiElement.enable();
            }
        });
    };
}

function bindBootstrapTabSelectEvent(tabsId) {
    $('#' + tabsId + ' > ul li a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        var tabName = $(e.target).attr("data-tab-name");
        $("#selected-tab-name").val(tabName);
    });
}

function display_kendoui_grid_error(e) {
    if (e.errors) {
        if ((typeof e.errors) == 'string') {
            //single error
            //display the message
            //alert(e.errors);
            CheckInputShowSelfNoIdTime("您没有权限查看！请联系管理员授权！", 20000);
        } else {
            //array of errors
            //source: http://docs.kendoui.com/getting-started/using-kendo-with/aspnet-mvc/helpers/grid/faq#how-do-i-display-model-state-errors?
            var message = "The following errors have occurred:";
            //create a message containing all errors.
            $.each(e.errors, function (key, value) {
                if (value.errors) {
                    message += "\n";
                    message += value.errors.join("\n");
                }
            });
            //display the message
            alert(message);
        }
      //ignore empty error
    } else if (e.errorThrown) {
        // alert('Error happened');
        CheckInputShowSelfNoIdTime("您没有权限查看！请联系管理员授权！", 5000);
    }
}

// CSRF (XSRF) security
function addAntiForgeryToken(data) {
    //if the object is undefined, create a new one.
    if (!data) {
        data = {};
    }
    //add token
    var tokenInput = $('input[name=__RequestVerificationToken]');
    if (tokenInput.length) {
        data.__RequestVerificationToken = tokenInput.val();
    }
    return data;
};

function saveUserPreferences(url, name, value) {
    var postData = {
        name: name,
        value: value
    };
    addAntiForgeryToken(postData);
    $.ajax({
        cache: false,
        url: url,
        type: 'post',
        data: postData,
        dataType: 'json',
        error: function(xhr, ajaxOptions, thrownError) {
            alert('Failed to save preferences.');
        }
    });
};

//scroll to top
(function ($) {
    $.fn.backTop = function () {
        var backBtn = this;

        var position = 1000;
        var speed = 900;

        $(document).scroll(function () {
            var pos = $(window).scrollTop();

            if (pos >= position) {
                backBtn.fadeIn(speed);
            } else {
                backBtn.fadeOut(speed);
            }
        });

        backBtn.click(function () {
            $("html, body").animate({ scrollTop: 0 }, 900);
        });
    }
}(jQuery));

// Ajax activity indicator bound to ajax start/stop document events
$(document).ajaxStart(function () {
    $('#ajaxBusy').show();
}).ajaxStop(function () {
    $('#ajaxBusy').hide();
});

//公共
function WeekName(n)
{
    var WeekName;
    switch (n) {
        case "1":
            WeekName = "星期一";
            break;
        case "2":
            WeekName = "星期二";
            break;
        case "3":
            WeekName = "星期三";
            break;
        case "4":
            WeekName = "星期四";
            break;
        case "5":
            WeekName = "星期五";
            break;
        case "6":
            WeekName = "星期六";
            break;
        case "7":
            WeekName = "星期日";
            break;
    };
    return WeekName;
}
function rtrim(s) {
    var lastIndex = s.lastIndexOf(',');
    if (lastIndex > -1) {
        s = s.substring(0, lastIndex);
    }
    return s;
}
function isNull(data) {
    return (data == "" || data == undefined || data == null) ? "" : data;
}

//刷新
function refresh() {
    window.location.reload();//刷新当前页面.

    //或者下方刷新方法
    //parent.location.reload()刷新父亲对象（用于框架）--需在iframe框架内使用
    // opener.location.reload()刷新父窗口对象（用于单开窗口
    //top.location.reload()刷新最顶端对象（用于多开窗口）
}
// sets "hidden" field on items matching query
function filter(dataSource, query) {
    var hasVisibleChildren = false;
    var data = dataSource instanceof kendo.data.HierarchicalDataSource && dataSource.data();
    for (var i = 0; i < data.length; i++) {
        var item = data[i];
        var text = item.text.toLowerCase();
        var itemVisible =
            query === true // parent already matches
            || query === "" // query is empty
            || text.indexOf(query) >= 0; // item text matches query

        var anyVisibleChildren = filter(item.children, itemVisible || query); // pass true if parent matches
        hasVisibleChildren = hasVisibleChildren || anyVisibleChildren || itemVisible;
        item.hidden = !itemVisible && !anyVisibleChildren;
    }
    if (data) {
        // re-apply filter on children
        dataSource.filter({ field: "hidden", operator: "neq", value: true });
    }
    return hasVisibleChildren;
}

function ExportIsComplete(key) {
    var iscomplete = false;
    var interval = setInterval(function () {
        var postData = {
            key: key,
        };
        $.ajax({
            type: 'GET',
            url: "/Comms/GetExportIsComplete",
            data: postData,
            dataType: 'json',
            success: function (data) {
                if (data == 1) {
                    LoadHide();
                    iscomplete = true;
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            },

        });
        if (iscomplete) {
            clearInterval(interval);
        }
    }, 2000);

}