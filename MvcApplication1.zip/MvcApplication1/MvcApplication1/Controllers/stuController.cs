﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using BLL;

namespace MvcApplication1.Controllers
{
    public class stuController : Controller
    {
        //
        // GET: /stu/

        public ActionResult uLogin()
        {
            return View();
        }
        /// <summary>
        /// 叶昂
        /// </summary>
        /// <returns></returns>
        /// 
        //按责任人统计
        public ActionResult ZeRenRenTonJi()
        {
            return View();
        }
        //收费明细
        public ActionResult ShouFeiMingXi()
        {
            return View();
        }
        //退费明细
        public ActionResult TuiFeiMingXi()
        {
            return View();
        }
        //学费结转明细
        public ActionResult XueFeiJieZhuanMingXi()
        {
            return View();
        }
        //物品销售明细
        public ActionResult WuPinXiaoShouMingXi()
        {
            return View();
        }
        //课程销售汇总
        public ActionResult KeChenXiaoShouHuiZon()
        {
            return View();
        }
        //学员课销报表
        public ActionResult XueYuanKeXiaoBaoBiao()
        {
            return View();
        }
        //学员费用汇总
        public ActionResult XueYuanFeiYonHuiZon()
        {
            return View();
        }
        //学员剩余课时
        public ActionResult XueYuanShenYuKeShi()
        {
            return View();
        }
        //过期学费查询
        public ActionResult GuoQiXueFeiChaXun()
        {
            return View();
        }


        /// <summary>
        /// 向聪
        /// </summary>
        /// <returns></returns>
        //作业和通知
        public ActionResult zy()
        {
            return View();
        }
        //评价维度
        public ActionResult pjwh()
        {
            return View();
        }
        //消息查询
        public ActionResult xxcx()
        {
            return View();
        }


        /// <summary>
        /// 胡智勇
        /// </summary>
        /// <returns></returns>
        //师生语>评价学生
        public ActionResult Evaluationofstudent()
        {
            return View();
        }

        //师生语>评价老师
        public ActionResult Evaluationofteacher()
        {
            return View();
        }


        /// <summary>
        /// 廖娜
        /// </summary>
        /// <returns></returns>
        //数据报表——业绩报表——老师业绩明细
        public ActionResult teather()
        {
            return View();

        }
        //数据报表--业绩报表--老师业绩汇总
        public ActionResult pool()
        {
            return View();

        }
        //数据报表--业绩报表--学管师业绩明细
        public ActionResult manager()
        {
            return View();

        }
        //数据报表--业绩报表--学管师业绩汇总
        public ActionResult huizong()
        {
            return View();

        }
        //数据报表--班级报表--老师带班统计
        public ActionResult classs()
        {
            return View();
        }
        //数据报表--班级报表--学员未出勤
        public ActionResult student()
        {
            return View();
        }
        //数据报表--班级报表--学员请假
        public ActionResult qingjia()
        {
            return View();
        }


        /// <summary>
        /// 陈湘镔
        /// </summary>
        /// <returns></returns>
        //校务平台——前台业务——收费
        public ActionResult charge()
        {
            return View();
        }

        //校务平台——前台业务——退费
        public ActionResult refund()
        {
            return View();
        }

        //校务平台——工作台——首页工作台
        public ActionResult Workbench()
        {
            return View();
        }

        //校务平台——教务管理——课表显示打印——按天显示
        public ActionResult DisplayByDay()
        {
            return View();
        }

        //校务平台——教务管理——课表显示打印——按周显示
        public ActionResult DisplayByWeek()
        {
            return View();
        }

        //校务平台——教务管理——课表显示打印——按月显示
        public ActionResult DisplayByMonth()
        {
            return View();
        }

        //校务平台——工作台——通知公告
        public ActionResult NoticeBulletin()
        {
            return View();
        }

        //校务平台——工作台——刷卡考勤
        public ActionResult Cardattendance()
        {
            return View();
        }

        //校务平台——工作台——刷卡离校
        public ActionResult Gtsbc()
        {
            return View();
        }

        //校务平台——系统设置——系统配置——综合设置
        public ActionResult ComprehensiveSetting()
        {
            return View();
        }

        //校务平台——系统设置——微信消息模板设置
        public ActionResult Wmts()
        {
            return View();
        }
       
        //public ActionResult ClassroomSetting()
        //{
        //    return View();
        //}
        //public ActionResult SelectClassroom()
        //{
        //    return Json(BLL.classsManager.SelectClassroom(), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult AddClassroom(classs cl)
        //{
        //    return Json(BLL.classsManager.AddClassroom(cl), JsonRequestBehavior.AllowGet);

        //}
        //public ActionResult DelClassroom(int no)
        //{
        //    return Json(BLL.classsManager.DelClassroom(no), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult EditClassroom(classs cl)
        //{
        //    return Json(BLL.classsManager.EditClassroom(cl), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult CheckIsTrue(int no)
        //{
        //    return Json(BLL.classsManager.CheckIsTrue(no), JsonRequestBehavior.AllowGet);
        //}


        /// <summary>
        /// 朱紫薇
        /// </summary>
        /// <returns></returns>
        //咨询管理>咨询学员管理
        public ActionResult ZiXunGuanLi()
        {
            return View();
        }

        //跟进/到访记录
        public ActionResult Arrive()
        {
            return View();
        }

        //试听管理
        public ActionResult Listen()
        {
            return View();
        }

        //课程管理
        public ActionResult Course()
        {
            return View();
        }

        //班级管理
        public ActionResult Classes()
        {
            return View();
        }

        //排课管理
        public ActionResult PaiClasses()
        {
            return View();
        }

        //考试管理
        public ActionResult Tests()
        {
            return View();
        }

        //学管师带班
        public ActionResult Teacher()
        {
            return View();
        }

        //参数设置 课程所属年级 Parameter  
        public ActionResult ParameterCourseGrade()
        {
            return View();
        }

        //参数设置 课程所属学科  
        public ActionResult Subject()
        {
            return View();
        }

        //参数设置 课程所属类型  
        public ActionResult CourseType()
        {
            return View();
        }

        //参数设置 课程所属规格  
        public ActionResult Specifications()
        {
            return View();
        }

        //参数设置 常用上课时长  
        public ActionResult ClassHour()
        {
            return View();
        }

        //参数设置 退费扣款项目  
        public ActionResult ReturnMoney()
        {
            return View();
        }

        //参数设置 学员请假原因  
        public ActionResult LeaveReson()
        {
            return View();
        }

        //参数设置 销售员工类型  
        public ActionResult EmployeeType()
        {
            return View();
        }

        //参数设置 员工岗位  
        public ActionResult Staffpost()
        {
            return View();
        }

        //参数设置 学员跟进方式  
        public ActionResult StudentsFollow()
        {
            return View();
        }

        //参数设置 咨询学员来源  
        public ActionResult ConsultStuSources()
        {
            return View();
        }

        //参数设置 咨询学员状态  
        public ActionResult ConsultStuStates()
        {
            return View();
        }

        //参数设置 承诺到访类型  
        public ActionResult Arrived()
        {
            return View();
        }

        //参数设置 沟通时学员状态  
        public ActionResult CommunicateStuStates()
        {
            return View();
        }

        //参数设置 无效沟通类型  
        public ActionResult FailCommunicate()
        {
            return View();
        }

        //参数设置 招生来源  
        public ActionResult EnrolmentSource()
        {
            return View();
        }

        //参数设置 考试类型  
        public ActionResult TestType()
        {
            return View();
        }

        //参数设置 考试项目   
        public ActionResult TestProject()
        {
            return View();
        }

        //节假日设置
        public ActionResult Holiday()
        {
            return View();
        }

        
        
        

        //功能
        //——陈湘镔
        //——用户登陆
        public ActionResult userLogin(string userName, string userPwd)
        {
            return Json(userManager.uLogin(userName,userPwd), JsonRequestBehavior.AllowGet);
        }


        ///<summary>
        ///胡智勇——教室设置
        /// </summary>

        //校务平台——系统设置——教室设置
        //新增教室信息
        public ActionResult AddClassroom(classs cl)
        {
            return Json(classsManager.AddClassroom(cl));
        }

        //显示数据
        public ActionResult SelectClassroom()
        {
            return Json(classsManager.SelectClassroom(), JsonRequestBehavior.AllowGet);
        }
        //修改教室信息
        public ActionResult EditClassroom(classs cl)
        {
            return Json(classsManager.EditClassroom(cl), JsonRequestBehavior.AllowGet);
        }
        //查询教室信息
        public ActionResult VariousSeach(string key)
        {
             return Json(classsManager.VariousSeach(key), JsonRequestBehavior.AllowGet);
        
        }

        //public ActionResult ClassroomSetting()
        //{
        //    return View();
        //}
        //public ActionResult SelectClassroom()
        //{
        //    return Json(BLL.classsManager.SelectClassroom(), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult AddClassroom(classs cl)
        //{
        //    return Json(BLL.classsManager.AddClassroom(cl), JsonRequestBehavior.AllowGet);

        //}
        //public ActionResult DelClassroom(int no)
        //{
        //    return Json(BLL.classsManager.DelClassroom(no), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult EditClassroom(classs cl)
        //{
        //    return Json(BLL.classsManager.EditClassroom(cl), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult CheckIsTrue(int no)
        //{
        //    return Json(BLL.classsManager.CheckIsTrue(no), JsonRequestBehavior.AllowGet);
        //}
    }
}
