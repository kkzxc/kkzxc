﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL;

namespace BLL
{
    //教室表
    public class classsManager

    {
        public static IQueryable SelectClassroom()
        {
            return classsService.SelectClassroom();
        }

        public static int AddClassroom(classs cl)
        {
            return classsService.AddClassroom(cl);
        }

        public static int DelClassroom(int no)
        {
            return classsService.DelClassroom(no);
        }

        public static int EditClassroom(classs cl)
        {
            return classsService.EditClassroom(cl);
        }

        public static int CheckIsTrue(int no)
        {
            return classsService.CheckIsTrue(no);
        }

        public static IQueryable VariousSeach(string key)
        {
            return classsService.VariousSeach(key);
        }
    }
}
