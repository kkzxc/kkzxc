﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using Models;
namespace Order.Controllers
{
    public class Default1Controller : Controller
    {
        //
        // GET: /Default1/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetAllOrder()
        {
            return Json(tb_billManager.GetAllOrder(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetById(string no)
        {
            return Json(tb_billManager.GetById(no), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetByIdDetail(string no)
        {
            return Json(tb_detailManager.GetByIdDetail(no), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetNoCount(string no)
        {
            return Json(tb_billManager.GetNoCount(no));

        }
        public ActionResult Add(tb_bill bill, List<tb_detail> list)
        {
            return Json(tb_billManager.Add(bill, list));
        }
        public ActionResult Edit(tb_bill bill, List<tb_detail> list)
        {
            return Json(tb_billManager.Edit(bill, list));
        }
        public ActionResult GetAutoNo(DateTime date)
        {
            return Json(tb_billManager.GetAutoNo(date), JsonRequestBehavior.AllowGet);
        }
        public ActionResult Pages(int pageIndex, int pageSize)
        {
            return Json(tb_billManager.Pages(pageIndex,pageSize), JsonRequestBehavior.AllowGet);
        }
        public ActionResult Del(string no)
        {
            return Json(tb_billManager.Del(no), JsonRequestBehavior.AllowGet);

        }
    }
}
