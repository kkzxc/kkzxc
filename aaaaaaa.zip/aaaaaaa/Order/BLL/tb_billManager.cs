﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL;
namespace BLL
{
    public class tb_billManager
    {
        public static IQueryable GetAllOrder()
        {
            return tb_billService.GetAllOrder();
        }
        public static IQueryable GetById(string no)
        {
            return tb_billService.GetById(no);
        }
        public static int GetNoCount(string no)
        {
            return tb_billService.GetNoCount(no);
        }
        public static int Add(tb_bill bill, List<tb_detail> list)
        {
            return tb_billService.Add(bill,list);
        }
        public static int Edit(tb_bill bill, List<tb_detail> list)
        {
            return tb_billService.Edit(bill,list);
        }
        public static string GetAutoNo(DateTime date)
        {
            return tb_billService.GetAutoNo(date);
        }
        public static PageList Pages(int pageIndex, int pageSize)
        {
            return tb_billService.Pages(pageIndex,pageSize);
        }
        public static int Del(string no)
        {
            return tb_billService.Del(no);
        }
    }
}
