﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace DAL
{
    public class tb_billService
    {
        public static PageList Pages(int pageIndex, int pageSize)
        {
            OrderEntities order = new OrderEntities();
            var obj = from p in order.tb_bill
                      orderby p.billno
                      select new
                      {
                          billno = p.billno,
                          billdate = p.billdate,
                          suppliername = p.suppliername,
                          buyer = p.buyer,
                          warehouse = p.warehouse,
                          department = p.department,
                          executor = p.executor,
                          supplieraddress = p.supplieraddress
                      };
            PageList list = new PageList();
            var rows = entity.tb_bill.Count();
            list.PageCount = rows % pageSize == 0 ? rows / pageSize : rows / pageSize + 1;
            list.DateList = obj.Skip((pageIndex - 1) * pageSize).Take(pageSize);
            return list;

        }

        /// <summary>
        /// 查询所有单据信息
        /// </summary>
        /// <returns></returns>
        public static IQueryable GetAllOrder()
        {
            OrderEntities order = new OrderEntities();
            var obj = from p in order.tb_bill
                      select new
                      {
                          billno = p.billno,
                          billdate = p.billdate,
                          suppliername = p.suppliername,
                          buyer = p.buyer,
                          warehouse = p.warehouse,
                          //计算总金额
                          total = p.tb_detail.Count() > 0 ? (from pp in p.tb_detail select pp.goodsmoneyamt).Sum() : 0
                      };
            return obj;

        }
        /// <summary>
        /// 根据编号查询对应的主表数据
        /// </summary>
        /// <param name="no"></param>
        /// <returns></returns>
        public static IQueryable GetById(string no)
        {
            OrderEntities entity = new OrderEntities();
            var obj = from p in entity.tb_bill
                      where p.billno == no
                      select new
                      {
                          billdate = p.billdate,
                          billno = p.billno,
                          buyer = p.buyer,
                          department = p.department,
                          executor = p.executor,
                          supplieraddress = p.supplieraddress,
                          suppliername = p.suppliername,
                          warehouse = p.warehouse

                      };
            return obj;
        }

        public static int Del(string no)
        {
            OrderEntities order = new OrderEntities();
            //先删除子表数据
            var list = from p in order.tb_detail where p.billno == no select p;
            foreach (var item in list)
            {
                order.tb_detail.Remove(item);
            }
            //先删除主表数据

            var obj = (from p in order.tb_bill where p.billno == no select p).First();buyer
            order.tb_bill.Remove(obj);
            
            return order.SaveChanges();
        }

        //判断编号是否存在
        public static int GetNoCount(string no)
        {
            OrderEntities entity = new OrderEntities();
            var obj = (from p in entity.tb_bill
                       where p.billno == no
                       select p).Count();
            return obj;
        }

        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="bill">主表数据</param>
        /// <param name="list">详表数据</param>
        /// <returns></returns>
        public static int Add(tb_bill bill, List<tb_detail> list)
        {
            OrderEntities order = new OrderEntities();
            //先添加主表数据
            order.tb_bill.Add(bill);
            //然后在添加详表数据
            foreach (var item in list)
            {
                order.tb_detail.Add(item);
            }
            return order.SaveChanges();
        }

        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="bill">主表数据</param>
        /// <param name="list">详表数据</param>
        /// <returns></returns>
        public static int Edit(tb_bill bill, List<tb_detail> list)
        {
            OrderEntities order = new OrderEntities();
            //修改主表数据
            var obj = (from p in order.tb_bill where p.billno == bill.billno select p).First();
            obj.billdate = bill.billdate;
            obj.buyer = bill.buyer;
            obj.department = bill.department;
            obj.executor = bill.executor;
            obj.supplieraddress = bill.supplieraddress;
            obj.suppliername = bill.suppliername;
            obj.warehouse = bill.suppliername;

            //根据编号删除该编号下所有的详表数据
            var detaillist = from p in order.tb_detail where p.billno == bill.billno select p;
            foreach (var item in detaillist)
            {
                order.tb_detail.Remove(item);
            }
            //添加新的详表数据
            foreach (var item in list)
            {
                order.tb_detail.Add(item);
            }
            return order.SaveChanges();
        }

        public static string GetAutoNo(DateTime date)
        {
            OrderEntities order = new OrderEntities();
            //将日期转换成指定格式的字符串
            string sdate = date.ToString("yyyyMMdd");
            var obj = from p in order.tb_bill where p.billno.Contains(sdate) select p.billno;
            //判断是否存在当前日期下的单号        
            if (obj.Count() > 0)
            {//存在当前日期下的单号 获取当前日期下最大的单号
                long maxNo = long.Parse(obj.Max());
                //然后在最大的单号上加+1
                return (maxNo + 1).ToString();
            }                       
            else
            {
                //不存在当前日期下的单号 yyyyMMdd001
                return sdate + "001";
            }

        }

        public static string shijian(DateTime date)
        {
            OrderEntities or = new OrderEntities();
            string sdate = date.ToString("yyyyMMdd");
            var str = from p in or.tb_bill where p.billno.Contains(sdate) select p.billno;
            if (str.Count() > 0)
            {
                long maxno = long.Parse(str.Max());
                return (maxno + 1).ToString();
            }
            else
            {
                return sdate + "001";
            }
        }

        public static string aa(DateTime date)
        {
            OrderEntities or = new OrderEntities();
            string sdate = date.ToString("yyyyMMdd");
            var str = from p in or.tb_bill where p.billno.Contains(sdate) select p.billno;
            if (str.Count() > 0)
            {
                long maxno = long.Parse(str.Max());
                return (maxno + 1).ToString();

            }
            else
            {
                return sdate + "001";
            }
        }


    }
}
