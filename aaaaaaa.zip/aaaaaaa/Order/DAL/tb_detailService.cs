﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
namespace DAL
{
    public class tb_detailService
    {
        public static IQueryable GetByIdDetail(string no)
        {
            OrderEntities entity = new OrderEntities();
            var obj = from p in entity.tb_detail
                      where p.billno == no
                      select new
                      {
                          billno = p.billno,  
                          lineid = p.lineid,
                          goodsmoneyamt = p.goodsmoneyamt,
                          goodsname = p.goodsname,
                          goodsnum = p.goodsnum,
                          goodsprice = p.goodsprice,
                          ispresent = p.ispresent
                      };
            return obj;
        }
    }
}
